# Project memory

## Product intent & audience

- Vite + React project for SYNTXRR STREAM, an Android-first LIVE companion/RTMP streaming app.
- App includes text-to-speech functionality for live event narration, deployed to Android via WebView (GitHub Actions workflow in `.github/workflows/android.yml`).

## Brand personality & voice

- Not yet established.

## Visual design & UX direction

- App has a `LiveCenterView` component with a TTS test button.
- User interaction patterns: first user gesture (pointerdown/keydown) is used to prime the TTS engine.

## Decisions, constraints & rationale

- Framework: Vite + React (vite-react).
- Intended package manager: **Bun** (`bun.lock` is the canonical lockfile).
- Vite 8 requires esbuild `^0.27.0 || ^0.28.0`; esbuild at `^0.28.0` (resolves to 0.28.2).
- `bun install --frozen-lockfile` succeeds (274 installs, 364 packages).
- `bun run build` succeeds: 1698 modules transformed, output to `dist/`.
- A stale `package-lock.json` from an earlier npm install still exists untouched.

- **P0-1 TTS fix** — Android WebView `speechSynthesis` silently fails without user-gesture unlock. Three-part fix:
  - **Gesture priming**: `prime()` sends silent (volume 0) utterance to unlock engine; called on first user interaction (one-time pointerdown/keydown listener in App.tsx) and explicitly before test button and live event triggers.
  - **Queue-aware cancel**: `cancel()` only fires when a pending utterance is queued behind an active one — prevents killing slow-starting Android speech.
  - **Voice loading retry + resume timer**: exponential retry (up to 5 attempts) for delayed Android voice init; periodic `synth.resume()` if engine pauses (backgrounding/stalls).
- TTS service interface unchanged (`speak`, `speakEvent`, `stop`, `updateConfig`) — no call-site modifications needed.

## Open questions & assumptions

- Whether to remove the stale `package-lock.json` — deferred until explicit user approval.
- Visual design and brand voice are still being refined; primary product purpose is to make SYNTXRR genuinely usable for LIVE alongside StreamingIn.
- Bundle size warning (578 kB main bundle) is non-blocking; may warrant code-splitting or lazy loading.
- P0-1 TTS fix needs validation on a real Android device — WebView speech engine behavior varies by device and Android version.

## SYNTXRR checkpoint workflow and current work

- Product goal: SYNTXRR STREAM must become genuinely useful for LIVE and be usable alongside StreamingIn. StreamingIn is the functional benchmark because it is already proven usable by many streamers; do not treat APK creation as the goal or copy its branding/UI.
- Workflow: start from the latest verified source ZIP in Library; inspect the full source and current checkpoint/gap tracker; compare existing behavior with the saved StreamingIn APK reverse-engineering reports; patch only a verified gap; run focused regression checks; then create the next ZIP checkpoint. Do not repeat completed features, do not ask the user to resend an available ZIP, do not push GitHub at each checkpoint, and do not ask the user to build an APK at each checkpoint.
- StreamingIn reference limits: the saved reports are static APK/schema/DEX/native metadata inspection, not a complete Kotlin/Java decompilation or physical-device runtime test. Use evidence confidence appropriately; do not invent exact backend or runtime behavior.
- V26: shared session-scoped video decode worker serializes up to two local MP4 layer frame extractions.
- V27: detects MediaProjection loss as `capture_lost`, ends current RTMP session, and asks for fresh consent on restart. This is not seamless in-session reshare.
- V28: local JSON preset import/export with referenced local media and ID remapping; not cloud sync or StreamingIn-compatible JSON.
- V29: structured Group/Supergroup model, inherited visibility/lock, and v2 transfer support.
- V30: whole-Group move/resize in Studio with one undo snapshot per gesture.
- V31: durable local preset background URI, Studio preview, and preset transfer media support. Its initial Mode B synthetic overlay background was later found to cover the opaque full-frame `ScreenSource`.
- V32: removes the unsafe synthetic Mode B background overlay and keeps background preview/transfer-only until MediaProjection becomes a true scene layer.
- V33: adds MediaProjection as a dedicated `SurfaceFilterRender` object layer using one consent token/VirtualDisplay, with readiness gated on the first captured frame.
- V34: corrects Fit geometry and inverse Sprite rotation mapping for quarter turns; Group child bounds are applied once. Crop Cover and arbitrary-angle rotation remain unsupported.
- V35 (current source checkpoint): selects a direct RootEncoder `VideoSource` for unchanged full-frame, ungrouped, opaque, no-background capture; selects the compatibility GL object layer for background, Group, geometry, quarter-turn rotation, or partial opacity. The direct source forwards frames into RootEncoder's existing GL render queue and matches RootEncoder 2.8.1 `ScreenSource` orientation semantics. This is not a reproduction of StreamingIn's proprietary GPU acceleration/fallback implementation. Engine is chosen before VirtualDisplay creation; no second capture or in-session engine switch is attempted.
- Next priority: verify V35 through an Android Gradle compile and real-device tests when the environment is available, then continue camera/video compositor layering, orientation updates and performance. StreamingIn's saved analysis is static APK/schema/DEX/native metadata inspection; runtime internals remain only partially known.
- Keep Group/Supergroup, V28 transfer, and V31 background preview/import/export completed; don't redo them unless a regression is found. Do not jump to transitions/cloud sync when a more fundamental Mode B composition layer is missing.
- Always disclose that full Android compilation, APK build, real-phone camera orientation during LIVE, camera+multiple-video performance, capture recovery, device-level preset behavior and StreamingIn interoperability remain unverified until actually tested. Do not report source tests as device tests.
