import { Capacitor, registerPlugin, type PluginListenerHandle } from '@capacitor/core';
import type { StreamEvent, StudioScreensaverSettings } from '../types';
import { StorageService } from './storage';
import type { NativeModeBOverlayElement, NativeModeBScreenCaptureLayer } from './modeBComposition';
import { canChangeActivePresetForSnapshot } from './modeBPresetSwitchPolicy';
import { isLiveOverlaySceneReplaceable } from './modeBLiveScenePolicy';
import { shouldLockModeBSceneMutations } from './modeBSceneMutationPolicy';
import { isSupportedScreensaverAssetSelection } from './modeBScreensaverPolicy';
import type { ModeBPresetTransitionSpec } from './modeBPresetTransitionPolicy';

export { createModeBOverlaySnapshot, createModeBScreenCaptureLayer } from './modeBComposition';

export type ModeBAudioSource = 'mix' | 'internal' | 'microphone';
export type ModeBStreamStatus = 'idle' | 'starting' | 'connecting' | 'live' | 'host_wait' | 'stopping' | 'stopped' | 'disconnected' | 'capture_lost' | 'reshare_waiting' | 'resharing' | 'error';

export interface StartModeBStreamOptions {
  rtmpUrl: string;
  width: number;
  height: number;
  videoBitrate: number;
  audioBitrate: number;
  fps: number;
  audioSource?: ModeBAudioSource;
  overlayElements?: NativeModeBOverlayElement[];
  screenCaptureLayer?: NativeModeBScreenCaptureLayer;
  backgroundAssetId?: string;
  sceneAssetNamespace: string;
  backgroundAssetNamespace?: string;
  screensaverAssetNamespace?: string;
  screensaver?: StudioScreensaverSettings | Record<string, unknown> | null;
}

export interface PreparedModeBOverlayAssets {
  sceneAssetNamespace: string;
  backgroundAssetNamespace: string;
  screensaverAssetNamespace: string;
}

export interface ModeBStreamSnapshot {
  status: ModeBStreamStatus;
  message: string;
  isStreaming: boolean;
  bitrateKbps: number;
  timestamp?: number;
}

export interface NativeModeBLiveEvent {
  id: string;
  type: string;
  username: string;
  detail: string;
  amount?: number;
  viewerCount?: number;
  totalLikeCount?: number;
  repeatCount?: number;
  timestamp: number;
}

interface NativeStreamingPluginInterface {
  clearOverlayAssets(): Promise<{ success: boolean }>;
  clearOverlayAssetNamespace(options: { assetNamespace: string }): Promise<{ success: boolean }>;
  uploadOverlayAsset(options: { id: string; mimeType: string; dataBase64: string; assetType?: 'image' | 'video'; assetNamespace?: string }): Promise<{ success: boolean; bytes: number }>;
  startStream(options: StartModeBStreamOptions): Promise<{
    success: boolean;
    status: ModeBStreamStatus;
    message?: string;
  }>;
  stopStream(): Promise<{
    success: boolean;
    status: ModeBStreamStatus;
  }>;
  requestScreenReshare(): Promise<{
    success: boolean;
    status: ModeBStreamStatus;
    isStreaming: boolean;
    message?: string;
  }>;
  setHostWait(options: { enabled: boolean }): Promise<{ success: boolean; status: ModeBStreamStatus; message?: string }>;
  replaceLiveScene(options: {
    overlayElements: NativeModeBOverlayElement[];
    screenCaptureLayer?: NativeModeBScreenCaptureLayer;
    backgroundAssetId?: string;
    backgroundAssetNamespace?: string;
    transitionOut?: ModeBPresetTransitionSpec | null;
    transitionIn?: ModeBPresetTransitionSpec | null;
    assetNamespace: string;
    screensaver?: StudioScreensaverSettings | Record<string, unknown> | null;
  }): Promise<{ success: boolean; status: ModeBStreamStatus; message?: string }>;
  getStatus(): Promise<ModeBStreamSnapshot>;
  pushOverlayEvent(event: NativeModeBLiveEvent): Promise<{ accepted: boolean }>;
  addListener(
    eventName: 'streamState',
    listenerFunc: (snapshot: ModeBStreamSnapshot) => void,
  ): Promise<PluginListenerHandle>;
}

const NativeStreaming = registerPlugin<NativeStreamingPluginInterface>('NativeStreaming');
let modeBOverlayForwardingActive = false;
let modeBSceneMutationLocked = true; // Fail closed on Android until the native service state is read once.

function updateModeBSceneMutationLock(snapshot: Pick<ModeBStreamSnapshot, 'status' | 'isStreaming'> | null | undefined): void {
  modeBSceneMutationLocked = shouldLockModeBSceneMutations(snapshot);
}

/** Synchronous fail-closed guard for high-frequency Studio edit callbacks. */
export function isModeBSceneMutationLocked(): boolean {
  return isNativeStreamingAvailable() && modeBSceneMutationLocked;
}

const MAX_MODE_B_IMAGE_BYTES = 5 * 1024 * 1024;
const MAX_MODE_B_TOTAL_IMAGE_BYTES = 12 * 1024 * 1024;
const MAX_MODE_B_IMAGE_ASSETS = 10; // up to 8 overlay images, one background, and one Screensaver image/GIF
const MAX_MODE_B_OVERLAY_IMAGE_ASSETS = 8;
const MAX_MODE_B_VIDEO_ASSETS = 2;
const MAX_MODE_B_VIDEO_BYTES = 12 * 1024 * 1024;
const MODE_B_IMAGE_MIME_TYPES = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif']);
const MODE_B_VIDEO_MIME_TYPES = new Set(['video/mp4']);

async function clearNativeOverlayAssetCacheQuietly(): Promise<void> {
  if (!isNativeStreamingAvailable()) return;
  try { await NativeStreaming.clearOverlayAssets(); } catch { /* cleanup must not hide the original start result */ }
}

async function clearNativeOverlayAssetNamespaceQuietly(assetNamespace: string): Promise<void> {
  if (!isNativeStreamingAvailable() || !assetNamespace) return;
  try { await NativeStreaming.clearOverlayAssetNamespace({ assetNamespace }); } catch { /* preserve primary result */ }
}

function createModeBAssetNamespace(prefix: 'scene' | 'background' | 'screensaver'): string {
  const randomPart = Math.random().toString(36).slice(2, 12).padEnd(8, '0');
  return `${prefix}_${Date.now().toString(36)}_${randomPart}`;
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Gagal membaca aset media Studio.'));
    reader.onload = () => {
      if (typeof reader.result !== 'string') {
        reject(new Error('Format aset media tidak dapat dibaca.'));
        return;
      }
      const separator = reader.result.indexOf(',');
      if (separator < 0) {
        reject(new Error('Data media Studio tidak valid.'));
        return;
      }
      resolve(reader.result.slice(separator + 1));
    };
    reader.readAsDataURL(blob);
  });
}

/**
 * Uploads an immutable scene media set into its own native directory. The preset background
 * has a separate session namespace because it remains mounted while overlay scenes change.
 * preserveExistingCache is used only for live scene staging; a new stream clears crash leftovers.
 */
export async function prepareModeBOverlayAssets(
  elements: NativeModeBOverlayElement[] | undefined | null,
  backgroundAssetId?: string,
  options: { preserveExistingCache?: boolean; screensaverAssetId?: string; screensaverAssetType?: 'image' | 'video' } = {},
): Promise<PreparedModeBOverlayAssets> {
  const sceneAssetNamespace = createModeBAssetNamespace('scene');
  const backgroundAssetNamespace = backgroundAssetId ? createModeBAssetNamespace('background') : '';
  const screensaverAssetId = typeof options.screensaverAssetId === 'string' ? options.screensaverAssetId.trim() : '';
  const screensaverAssetType = options.screensaverAssetType === 'video' ? 'video' : 'image';
  const screensaverAssetNamespace = screensaverAssetId ? createModeBAssetNamespace('screensaver') : '';
  if (!isNativeStreamingAvailable()) return { sceneAssetNamespace, backgroundAssetNamespace, screensaverAssetNamespace };

  const visualElements = (Array.isArray(elements) ? elements : [])
    .filter((element) => element && element.visible !== false &&
      (element.type === 'image' || element.type === 'sticker' || element.type === 'video'));
  const videoElements = visualElements.filter((element) => element.type === 'video');
  const imageIdsRaw = visualElements
    .filter((element) => element.type === 'image' || element.type === 'sticker')
    .map((element) => element.properties?.imageAssetId)
    .filter((id): id is string => typeof id === 'string' && id.trim().length > 0);
  const videoIdsRaw = visualElements
    .filter((element) => element.type === 'video')
    .map((element) => element.properties?.videoAssetId)
    .filter((id): id is string => typeof id === 'string' && id.trim().length > 0);
  if (videoIdsRaw.length !== videoElements.length) {
    throw new Error('Mode B hanya dapat merender video MP4 lokal dari Pustaka Media. URL video remote belum didukung.');
  }
  const allIds = [...imageIdsRaw, ...videoIdsRaw, ...(backgroundAssetId ? [backgroundAssetId] : []), ...(screensaverAssetId ? [screensaverAssetId] : [])];
  if (allIds.some((id) => !/^[A-Za-z0-9_-]{1,100}$/.test(id))) {
    throw new Error('Identitas aset media Studio tidak valid. Hapus lalu impor ulang media tersebut.');
  }
  const imageIds = Array.from(new Set(imageIdsRaw));
  const videoIds = Array.from(new Set(videoIdsRaw));
  const allUniqueImageIds = Array.from(new Set([
    ...imageIds,
    ...(backgroundAssetId ? [backgroundAssetId] : []),
    ...(screensaverAssetId && screensaverAssetType === 'image' ? [screensaverAssetId] : []),
  ]));
  if (imageIds.length > MAX_MODE_B_OVERLAY_IMAGE_ASSETS) {
    throw new Error(`Preset memiliki lebih dari ${MAX_MODE_B_OVERLAY_IMAGE_ASSETS} gambar/sticker overlay lokal. Kurangi aset agar compositor tetap ringan.`);
  }
  if (allUniqueImageIds.length > MAX_MODE_B_IMAGE_ASSETS) {
    throw new Error('Preset memiliki terlalu banyak gambar untuk overlay, background, dan screensaver. Kurangi aset agar compositor tetap ringan.');
  }
  if (videoIds.length > MAX_MODE_B_VIDEO_ASSETS) {
    throw new Error(`Preset memiliki lebih dari ${MAX_MODE_B_VIDEO_ASSETS} video MP4 lokal berbeda. Kurangi jumlah klip pada kanvas.`);
  }

  try {
    if (!options.preserveExistingCache) {
      const cleared = await NativeStreaming.clearOverlayAssets();
      if (!cleared?.success) throw new Error('Cache media native tidak dapat disiapkan.');
    }
    await NativeStreaming.clearOverlayAssetNamespace({ assetNamespace: sceneAssetNamespace });
    if (backgroundAssetNamespace) {
      await NativeStreaming.clearOverlayAssetNamespace({ assetNamespace: backgroundAssetNamespace });
    }
    if (screensaverAssetNamespace) {
      await NativeStreaming.clearOverlayAssetNamespace({ assetNamespace: screensaverAssetNamespace });
    }
    if (allUniqueImageIds.length === 0 && videoIds.length === 0 && !screensaverAssetId) {
      return { sceneAssetNamespace, backgroundAssetNamespace, screensaverAssetNamespace };
    }

    const assets = await StorageService.getStudioMediaAssetsByIds([...new Set([...allUniqueImageIds, ...videoIds, ...(screensaverAssetId ? [screensaverAssetId] : [])])]);
    const byId = new Map<string, (typeof assets)[number]>();
    for (const asset of assets) byId.set(asset.id, asset);
    let totalImageBytes = 0;
    let totalVideoBytes = 0;

    const uploadAsset = async (id: string, expectedType: 'image' | 'video', assetNamespace: string) => {
      const asset = byId.get(id);
      if (!asset || asset.type !== expectedType) {
        throw new Error(`Aset ${expectedType === 'video' ? 'video' : 'gambar'} Studio ${id} tidak ditemukan di penyimpanan lokal. Buka Studio dan impor ulang aset tersebut.`);
      }
      const mimeType = (asset.mimeType || asset.blob.type || '').toLowerCase();
      const sizeBytes = asset.blob.size > 0 ? asset.blob.size : (asset.sizeBytes || 0);
      if (expectedType === 'image') {
        if (!MODE_B_IMAGE_MIME_TYPES.has(mimeType)) {
          throw new Error(`Format gambar ${asset.name} belum didukung. Gunakan PNG, JPG, WebP, atau GIF.`);
        }
        if (sizeBytes <= 0 || sizeBytes > MAX_MODE_B_IMAGE_BYTES) {
          throw new Error(`Gambar ${asset.name} kosong atau terlalu besar. Batas per gambar adalah 5 MB.`);
        }
        totalImageBytes += sizeBytes;
        if (totalImageBytes > MAX_MODE_B_TOTAL_IMAGE_BYTES) {
          throw new Error('Total gambar/sticker/background preset melebihi 12 MB. Kurangi jumlah atau ukuran aset.');
        }
      } else {
        if (!MODE_B_VIDEO_MIME_TYPES.has(mimeType)) {
          throw new Error(`Video ${asset.name} belum didukung untuk siaran native. Gunakan file MP4.`);
        }
        if (sizeBytes <= 0 || sizeBytes > MAX_MODE_B_VIDEO_BYTES) {
          throw new Error(`Video ${asset.name} kosong atau terlalu besar. Batas setiap klip MP4 lokal adalah 12 MB, dengan total gabungan maksimal 12 MB.`);
        }
        totalVideoBytes += sizeBytes;
        if (totalVideoBytes > MAX_MODE_B_VIDEO_BYTES) {
          throw new Error('Total video preset melebihi 12 MB.');
        }
      }
      const result = await NativeStreaming.uploadOverlayAsset({
        id,
        mimeType,
        assetType: expectedType,
        assetNamespace,
        dataBase64: await blobToBase64(asset.blob),
      });
      if (!result?.success) throw new Error(`Aset ${asset.name} gagal disiapkan untuk encoder.`);
    };

    // The shared background is uploaded separately and is never removed during scene swaps.
    for (const id of imageIds) await uploadAsset(id, 'image', sceneAssetNamespace);
    for (const id of videoIds) await uploadAsset(id, 'video', sceneAssetNamespace);
    if (screensaverAssetId && screensaverAssetNamespace) {
      const screensaverAsset = byId.get(screensaverAssetId);
      if (!screensaverAsset) {
        throw new Error('Media Screensaver tidak ditemukan di Pustaka Media. Impor ulang file tersebut.');
      }
      const screensaverMime = (screensaverAsset.mimeType || screensaverAsset.blob?.type || '').toLowerCase();
      if (!isSupportedScreensaverAssetSelection(screensaverAssetType, screensaverAsset.type, screensaverMime)) {
        throw new Error(screensaverAssetType === 'video'
          ? 'Screensaver video hanya menerima MP4 lokal. Pilih ulang file MP4.'
          : 'Screensaver hanya menerima PNG, JPG, atau GIF lokal. Pilih ulang media yang sesuai.');
      }
      await uploadAsset(screensaverAssetId, screensaverAssetType, screensaverAssetNamespace);
    }
    if (backgroundAssetId && backgroundAssetNamespace) {
      await uploadAsset(backgroundAssetId, 'image', backgroundAssetNamespace);
    }
    return { sceneAssetNamespace, backgroundAssetNamespace, screensaverAssetNamespace };
  } catch (error) {
    await clearNativeOverlayAssetNamespaceQuietly(sceneAssetNamespace);
    if (backgroundAssetNamespace) await clearNativeOverlayAssetNamespaceQuietly(backgroundAssetNamespace);
    if (screensaverAssetNamespace) await clearNativeOverlayAssetNamespaceQuietly(screensaverAssetNamespace);
    throw error;
  }
}

/** Forwards real (non-simulated) StreamEvent data to the active native Mode B overlay compositor. */
export function forwardModeBOverlayEvent(event: StreamEvent): void {
  if (!event || event.isSimulation || !modeBOverlayForwardingActive || !isNativeStreamingAvailable()) return;
  const payload: NativeModeBLiveEvent = {
    id: String(event.id || '').slice(0, 120),
    type: String(event.type || 'custom').slice(0, 40),
    username: String(event.username || '').slice(0, 80),
    detail: String(event.detail || '').slice(0, 500),
    timestamp: Number.isFinite(event.timestamp) ? event.timestamp : Date.now(),
  };
  const eventAmount = typeof event.amount === 'number' ? event.amount
    : typeof event.diamondCount === 'number' ? event.diamondCount
    : typeof event.likeCount === 'number' ? event.likeCount : undefined;
  if (typeof eventAmount === 'number' && Number.isFinite(eventAmount)) payload.amount = Math.max(0, Math.min(1_000_000, eventAmount));
  if (typeof event.viewerCount === 'number' && Number.isFinite(event.viewerCount)) payload.viewerCount = Math.max(0, Math.min(10_000_000, event.viewerCount));
  if (typeof event.totalLikeCount === 'number' && Number.isFinite(event.totalLikeCount)) payload.totalLikeCount = Math.max(0, Math.min(2_000_000_000, event.totalLikeCount));
  if (typeof event.repeatCount === 'number' && Number.isFinite(event.repeatCount)) payload.repeatCount = Math.max(0, Math.min(1_000_000, event.repeatCount));
  void NativeStreaming.pushOverlayEvent(payload).catch(() => undefined);
}

/**
 * Returns true only when the native Mode B service is in a confirmed terminal/idle state.
 * An unavailable or unreadable native status is treated as locked so Studio cannot silently
 * diverge from the immutable scene snapshot currently being sent to RTMP.
 */
/**
 * Replaces the native aggregate overlay in the current RTMP session. Scene images, stickers,
 * and MP4 files are uploaded to a new immutable namespace. Native service owns namespace cleanup
 * after a rejected or completed handoff so Java decoders never race file deletion.
 */
export async function replaceModeBLiveOverlayScene(options: {
  overlayElements: NativeModeBOverlayElement[];
  screenCaptureLayer?: NativeModeBScreenCaptureLayer;
  /** Current background identity from the active preset; used to stage only an actual change. */
  activeBackgroundAssetId?: string;
  backgroundAssetId?: string;
  transitionOut?: ModeBPresetTransitionSpec | null;
  transitionIn?: ModeBPresetTransitionSpec | null;
  screensaver?: StudioScreensaverSettings | Record<string, unknown> | null;
  screensaverAssetId?: string;
  screensaverAssetType?: 'image' | 'video';
}): Promise<{ success: boolean; message: string }> {
  if (!isNativeStreamingAvailable()) {
    return { success: false, message: 'Pergantian scene LIVE native hanya tersedia pada APK Android.' };
  }
  if (!isLiveOverlaySceneReplaceable(options.overlayElements)) {
    return {
      success: false,
      message: 'Pergantian LIVE mendukung teks, widget, gambar, stiker, MP4 lokal, dan kamera dengan pemilik lensa yang sama. Penambahan kamera atau perubahan lensa memerlukan LIVE dihentikan lalu dimulai ulang.',
    };
  }

  let stagedAssets: PreparedModeBOverlayAssets | null = null;
  try {
    const activeBackgroundId = options.activeBackgroundAssetId || '';
    const nextBackgroundId = options.backgroundAssetId || '';
    const backgroundChanged = activeBackgroundId !== nextBackgroundId;
    stagedAssets = await prepareModeBOverlayAssets(
      options.overlayElements,
      backgroundChanged && nextBackgroundId ? nextBackgroundId : undefined,
      { preserveExistingCache: true, screensaverAssetId: options.screensaverAssetId, screensaverAssetType: options.screensaverAssetType },
    );
    const result = await NativeStreaming.replaceLiveScene({
      overlayElements: options.overlayElements,
      screenCaptureLayer: options.screenCaptureLayer,
      backgroundAssetId: nextBackgroundId,
      backgroundAssetNamespace: backgroundChanged ? stagedAssets.backgroundAssetNamespace : '',
      screensaverAssetNamespace: stagedAssets.screensaverAssetNamespace,
      transitionOut: options.transitionOut ?? null,
      transitionIn: options.transitionIn ?? null,
      screensaver: options.screensaver ?? null,
      assetNamespace: stagedAssets.sceneAssetNamespace,
    });
    // Native service owns cleanup after a scene request reaches it. Never delete staging files
    // here: a decoder may still be reading them while native rollback/retirement completes.
    return {
      success: result?.success === true,
      message: result?.message || (result?.success ? 'Scene overlay diperbarui pada output LIVE.' : 'Scene overlay tidak dapat diperbarui.'),
    };
  } catch (error) {
    // Keep an uploaded namespace intact if the native call outcome is uncertain. The native
    // session cleanup removes orphaned namespaces after all scene decoders have released files.
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Gagal mengganti scene overlay pada output LIVE.',
    };
  }
}

export async function canChangeActivePresetDuringModeB(): Promise<boolean> {
  if (!isNativeStreamingAvailable()) return true;
  try {
    const snapshot = await NativeStreaming.getStatus();
    return canChangeActivePresetForSnapshot(snapshot);
  } catch {
    return false;
  }
}

/** Shows or hides the Mode B host-wait screen while preserving the current RTMP session. */
export async function setModeBHostWait(enabled: boolean): Promise<ModeBStreamSnapshot> {
  if (!isNativeStreamingAvailable()) {
    return { status: 'error', message: 'Layar tunggu LIVE hanya tersedia pada APK Android.', isStreaming: false, bitrateKbps: 0 };
  }
  try {
    const result = await NativeStreaming.setHostWait({ enabled });
    const snapshot = await NativeStreaming.getStatus();
    updateModeBSceneMutationLock(snapshot);
    return {
      status: snapshot.status || result.status || (enabled ? 'host_wait' : 'live'),
      message: snapshot.message || result.message || (enabled ? 'Layar tunggu ditampilkan.' : 'Tampilan LIVE dilanjutkan.'),
      isStreaming: snapshot.isStreaming === true,
      bitrateKbps: snapshot.bitrateKbps || 0,
      timestamp: Date.now(),
    };
  } catch (error) {
    return { status: 'error', message: error instanceof Error ? error.message : 'Layar tunggu tidak dapat diubah.', isStreaming: false, bitrateKbps: 0 };
  }
}

export function isNativeStreamingAvailable(): boolean {
  try {
    return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
  } catch {
    return false;
  }
}

export async function startModeBStream(options: StartModeBStreamOptions): Promise<ModeBStreamSnapshot> {
  if (!isNativeStreamingAvailable()) {
    return {
      status: 'error',
      message: 'Encoder RTMP native hanya tersedia pada APK Android.',
      isStreaming: false,
      bitrateKbps: 0,
    };
  }

  const endpoint = options.rtmpUrl.trim();
  if (!/^rtmps?:\/\//i.test(endpoint)) {
    await clearNativeOverlayAssetCacheQuietly();
    return {
      status: 'error',
      message: 'Gunakan alamat server RTMP atau RTMPS yang valid.',
      isStreaming: false,
      bitrateKbps: 0,
    };
  }

  // Lock Studio scene mutations before opening Android's permission flow. The native service
  // does not publish `starting` until the user has granted MediaProjection consent, so waiting
  // for the plugin result would leave a window where Studio could diverge from the start snapshot.
  updateModeBSceneMutationLock({ status: 'starting', isStreaming: false });
  try {
    const result = await NativeStreaming.startStream(options);
    modeBOverlayForwardingActive = result.success && result.status !== 'error';
    updateModeBSceneMutationLock({ status: result.status, isStreaming: false });
    if (!modeBOverlayForwardingActive) await clearNativeOverlayAssetCacheQuietly();
    return {
      status: result.status || 'starting',
      message: result.message || 'Memulai capture dan encoder native.',
      isStreaming: false,
      bitrateKbps: 0,
    };
  } catch (error) {
    modeBOverlayForwardingActive = false;
    updateModeBSceneMutationLock({ status: 'error', isStreaming: false });
    await clearNativeOverlayAssetCacheQuietly();
    return {
      status: 'error',
      message: error instanceof Error ? error.message : 'Gagal memulai encoder native.',
      isStreaming: false,
      bitrateKbps: 0,
    };
  }
}

/** Requests a fresh Android screen-capture token while keeping the existing RTMP session alive. */
export async function requestModeBScreenReshare(): Promise<ModeBStreamSnapshot> {
  if (!isNativeStreamingAvailable()) {
    return { status: 'error', message: 'Pemulihan berbagi layar hanya tersedia pada APK Android.', isStreaming: false, bitrateKbps: 0 };
  }
  updateModeBSceneMutationLock({ status: 'reshare_waiting', isStreaming: true });
  try {
    const result = await NativeStreaming.requestScreenReshare();
    const streaming = result.isStreaming === true;
    modeBOverlayForwardingActive = streaming;
    updateModeBSceneMutationLock({ status: result.status, isStreaming: streaming });
    return {
      status: result.status || (streaming ? 'reshare_waiting' : 'error'),
      message: result.message || (streaming ? 'LIVE tetap berjalan; menunggu layar dibagikan kembali.' : 'Tidak dapat meminta izin layar baru.'),
      isStreaming: streaming,
      bitrateKbps: 0,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Gagal meminta izin layar baru.';
    try {
      const snapshot = await NativeStreaming.getStatus();
      modeBOverlayForwardingActive = snapshot.isStreaming === true;
      updateModeBSceneMutationLock(snapshot);
      return { ...snapshot, message: snapshot.isStreaming ? message : snapshot.message };
    } catch {
      modeBOverlayForwardingActive = false;
      updateModeBSceneMutationLock(null);
      return { status: 'error', message, isStreaming: false, bitrateKbps: 0 };
    }
  }
}

export async function stopModeBStream(): Promise<ModeBStreamSnapshot> {
  if (!isNativeStreamingAvailable()) {
    return { status: 'idle', message: 'Encoder native tidak aktif di browser.', isStreaming: false, bitrateKbps: 0 };
  }
  try {
    const result = await NativeStreaming.stopStream();
    modeBOverlayForwardingActive = false;
    updateModeBSceneMutationLock({ status: result.status || 'stopping', isStreaming: false });
    return {
      status: result.status || 'stopping',
      message: 'Permintaan berhenti dikirim ke encoder native.',
      isStreaming: false,
      bitrateKbps: 0,
    };
  } catch (error) {
    modeBOverlayForwardingActive = false;
    updateModeBSceneMutationLock(null);
    return {
      status: 'error',
      message: error instanceof Error ? error.message : 'Gagal menghentikan encoder native.',
      isStreaming: false,
      bitrateKbps: 0,
    };
  }
}

export async function getModeBStreamStatus(): Promise<ModeBStreamSnapshot> {
  if (!isNativeStreamingAvailable()) {
    return { status: 'idle', message: 'Mode B native belum tersedia di browser.', isStreaming: false, bitrateKbps: 0 };
  }
  try {
    const snapshot = await NativeStreaming.getStatus();
    modeBOverlayForwardingActive = snapshot.isStreaming || ['starting', 'connecting', 'live', 'reshare_waiting', 'resharing'].includes(snapshot.status);
    updateModeBSceneMutationLock(snapshot);
    return snapshot;
  } catch (error) {
    updateModeBSceneMutationLock(null);
    return {
      status: 'error',
      message: error instanceof Error ? error.message : 'Tidak dapat membaca status encoder.',
      isStreaming: false,
      bitrateKbps: 0,
    };
  }
}

export function onModeBStreamState(
  listener: (snapshot: ModeBStreamSnapshot) => void,
): Promise<PluginListenerHandle | null> {
  if (!isNativeStreamingAvailable()) return Promise.resolve(null);
  return NativeStreaming.addListener('streamState', (snapshot) => {
    modeBOverlayForwardingActive = snapshot.isStreaming || ['starting', 'connecting', 'live', 'reshare_waiting', 'resharing'].includes(snapshot.status);
    updateModeBSceneMutationLock(snapshot);
    listener(snapshot);
  });
}
