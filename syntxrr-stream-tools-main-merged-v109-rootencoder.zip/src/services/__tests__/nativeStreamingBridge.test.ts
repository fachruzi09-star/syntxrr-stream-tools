import { createModeBOverlaySnapshot, createModeBScreenCaptureLayer } from '../modeBComposition';

let assertionCount = 0;

function assert(condition: unknown, message: string): void {
  assertionCount += 1;
  if (!condition) throw new Error(`Assertion failed: ${message}`);
}

function assertEqual<T>(actual: T, expected: T, message: string): void {
  assertionCount += 1;
  if (actual !== expected) throw new Error(`Assertion failed (${message}): expected=${String(expected)} actual=${String(actual)}`);
}

const element = {
  id: 'overlay_text',
  name: 'Overlay Text',
  type: 'text',
  x: 10,
  y: 12,
  width: 40,
  height: 10,
  layer: 1,
  visible: true,
  locked: false,
  opacity: 100,
  rotation: 0,
  properties: { text: 'LIVE' },
};

const snapshot = createModeBOverlaySnapshot([element]);
assertEqual(snapshot.length, 1, 'native snapshot contains only actual Studio overlay elements');
assertEqual(snapshot[0].id, element.id, 'the original Studio overlay is retained');
assertEqual(snapshot[0].type, 'text', 'ordinary overlay element type is preserved');
assertEqual(snapshot[0].properties.text, 'LIVE', 'allowed text properties are retained');
assertEqual(snapshot.some((item) => item.id === 'syntxrr_preset_background'), false, 'preset background is never synthesized as a post-capture overlay');
assertEqual(snapshot[0].properties['imageUrl'], undefined, 'arbitrary WebView media URLs never cross the native bridge');
const noElements = createModeBOverlaySnapshot(null);
assertEqual(noElements.length, 0, 'null input returns an empty overlay snapshot');

const manyElements = Array.from({ length: 60 }, (_, index) => ({
  ...element,
  id: `element_${index}`,
  layer: index + 1,
}));
const boundedSnapshot = createModeBOverlaySnapshot(manyElements);
assertEqual(boundedSnapshot.length, 60, 'the native overlay bound still accepts 60 actual Studio elements');
assertEqual(boundedSnapshot[0].id, 'element_0', 'the first item remains ordered by its Studio layer');
assertEqual(boundedSnapshot[59].id, 'element_59', 'the last item remains ordered by its Studio layer');
const reorderedSnapshot = createModeBOverlaySnapshot([
  { ...element, id: 'higher', layer: 9 },
  { ...element, id: 'lower', layer: 2 },
]);
assertEqual(reorderedSnapshot[0].id, 'lower', 'overlay layers sort by ascending Studio z-index');
assertEqual(reorderedSnapshot[1].id, 'higher', 'higher Studio z-index renders later');
const hiddenBoundedSnapshot = createModeBOverlaySnapshot([
  ...manyElements,
  { ...element, id: 'hidden_over_limit', layer: 61, visible: false },
]);
assertEqual(hiddenBoundedSnapshot.length, 60, 'invisible elements do not consume the native overlay bound');

let oversizedSnapshotRejected = false;
try {
  createModeBOverlaySnapshot([...manyElements, { ...element, id: 'element_60', layer: 61 }]);
} catch (error) {
  oversizedSnapshotRejected = error instanceof Error && error.message.includes('60 elemen');
}
assert(oversizedSnapshotRejected, 'snapshot rejects more than 60 visible Studio overlay elements');

// The screen capture is a separate MediaProjection object layer, never part of the
// aggregate Studio ViewFilterRender overlay snapshot.
const screenCaptureElement = {
  id: 'screen_main', name: 'Tangkapan Layar', type: 'screen_capture',
  x: 0, y: 20, width: 100, height: 56, layer: 1, visible: true,
  opacity: 100, rotation: 0, properties: { cropMode: 'fit' },
};
const screenLayer = createModeBScreenCaptureLayer([
  screenCaptureElement,
  { ...element, id: 'camera_top', type: 'camera', layer: 2 },
]);
assertEqual(screenLayer.enabled, true, 'visible screen capture creates an active projection layer');
assertEqual(screenLayer.y, 20, 'screen capture y position is retained');
assertEqual(screenLayer.width, 100, 'screen capture width is retained');
assertEqual(screenLayer.cropMode, 'fit', 'Fit is the explicit supported source crop mode');
assertEqual(screenLayer.grouped, false, 'an ungrouped screen element remains eligible for direct-source evaluation');
const groupedScreenLayer = createModeBScreenCaptureLayer([screenCaptureElement], true);
assertEqual(groupedScreenLayer.grouped, true, 'Group membership is forwarded for native capture-engine selection');
assertEqual(createModeBOverlaySnapshot([screenCaptureElement]).length, 0,
  'screen capture is not duplicated inside the aggregate Studio overlay view');
assertEqual(createModeBScreenCaptureLayer([]).width, 100,
  'presets without an explicit screen layer retain full-frame capture compatibility');
assertEqual(createModeBScreenCaptureLayer([{ ...screenCaptureElement, visible: false }]).enabled, false,
  'a hidden screen capture element disables only the visual projection layer');

let duplicateCaptureRejected = false;
try {
  createModeBScreenCaptureLayer([
    screenCaptureElement,
    { ...screenCaptureElement, id: 'screen_second', layer: 2 },
  ]);
} catch (error) {
  duplicateCaptureRejected = error instanceof Error && error.message.includes('satu elemen');
}
assert(duplicateCaptureRejected, 'two visible projection layers are rejected because the session owns one VirtualDisplay');

let captureLayerOrderRejected = false;
try {
  createModeBScreenCaptureLayer([
    screenCaptureElement,
    { ...element, id: 'below_capture', type: 'text', layer: 0 },
  ]);
} catch (error) {
  captureLayerOrderRejected = error instanceof Error && error.message.includes('layer paling bawah');
}
assert(captureLayerOrderRejected, 'screen capture must be below aggregate Studio overlays');

let unsupportedCropRejected = false;
try {
  createModeBScreenCaptureLayer([
    { ...screenCaptureElement, properties: { cropMode: 'cover' } },
  ]);
} catch (error) {
  unsupportedCropRejected = error instanceof Error && error.message.includes('Fit');
}
assert(unsupportedCropRejected, 'unsupported crop modes are rejected instead of stretched silently');

const rotatedScreenLayer = createModeBScreenCaptureLayer([
  { ...screenCaptureElement, rotation: 270, x: 18, y: 12, width: 54, height: 36 },
  { ...element, id: 'group_child_overlay', type: 'camera', layer: 2, x: 26, y: 20, width: 18, height: 18 },
]);
assertEqual(rotatedScreenLayer.rotation, 270, 'quarter-turn capture rotation survives native snapshot normalization');
assertEqual(rotatedScreenLayer.x, 18, 'group-transformed child x bounds are sent as absolute Studio coordinates');
assertEqual(rotatedScreenLayer.y, 12, 'group-transformed child y bounds are sent as absolute Studio coordinates');
assertEqual(rotatedScreenLayer.width, 54, 'group-transformed child width is sent as an absolute Studio bound');

let unsupportedRotationRejected = false;
try {
  createModeBScreenCaptureLayer([{ ...screenCaptureElement, rotation: 45 }]);
} catch (error) {
  unsupportedRotationRejected = error instanceof Error && error.message.includes('0°, 90°, 180°, atau 270°');
}
assert(unsupportedRotationRejected, 'oblique capture rotation is rejected until a pixel-aspect-correct shader path exists');

console.log(`Native streaming and projection layer tests passed: ${assertionCount} assertions.`);
